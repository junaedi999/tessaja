<?php


$email = "xxxxxxxxxxxxxxx";
$password = "xxxxxxxxxxxx";

$user_agent = "Android/5.1; Bermi/1.39.0; Manufacturer/OPPO; Model/A1603; Gaoiscoolman";


?>



